
***
## <a name="maintainers"> </a>MAINTAINERS/CREDITS
* [Gaus Surahman](https://drupal.org/user/159062)
* [Splide Contributors](https://www.drupal.org/node/3215092/committers)
* [Slick Contributors](https://www.drupal.org/node/2232779/committers)
* CHANGELOG.txt for helpful souls with their patches, suggestions and reports.


## READ MORE
See the project page on drupal.org:

[Splide](http://drupal.org/project/splide)

More info relevant to each option is available at their form display by hovering
over them, and clicking a dark question mark.

See the Splide docs at:

* [Splide website](https://splidejs.com/)
* [Splide at github](https://github.com/Splidejs/splide)

[&#10548; Back to Top](#top)
