<?php

namespace Drupal\splide\Form;

/**
 * Provides resusable admin functions or form elements.
 *
 * @todo extends Drupal\blazy\Form\BlazyAdminInteropInterface post Blazy:2.6+.
 */
interface SplideAdminInterface {}
