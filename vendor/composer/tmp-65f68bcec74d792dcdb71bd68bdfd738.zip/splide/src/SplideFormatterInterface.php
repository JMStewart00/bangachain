<?php

namespace Drupal\splide;

use Drupal\blazy\BlazyFormatterInterface;

/**
 * Defines re-usable services and functions for splide field plugins.
 */
interface SplideFormatterInterface extends BlazyFormatterInterface {}
