<?php

namespace Drupal\blazy;

use Drupal\blazy\Media\BlazyOEmbed as OEmbed;

/**
 * Provides OEmbed integration.
 *
 * @todo deprecated at 2.6, and removed at 3.x. Use
 * Drupal\blazy\Media\BlazyOEmbed instead.
 */
class BlazyOEmbed extends OEmbed {}
