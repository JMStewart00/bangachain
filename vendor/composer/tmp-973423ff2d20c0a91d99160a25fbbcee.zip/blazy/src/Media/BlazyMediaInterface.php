<?php

namespace Drupal\blazy\Media;

/**
 * Provides extra utilities to work with core Media.
 *
 * @todo remove, unless you can make it non-static before 3.x+.
 */
interface BlazyMediaInterface {}
